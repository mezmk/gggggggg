import requests
import json

# إعدادات السيرفر
API_URL = "http://93.190.143.157:3000/api/external/receive-sms"

def send_sms_to_panel(sender, receiver, message, cli="EXTERNAL_BOT"):
    """
    وظيفة لإرسال بيانات الرسالة إلى لوحة Abyss Panel
    sender: رقم المرسل
    receiver: الرقم المستلم (الموجود في اللوحة)
    message: نص الرسالة
    cli: اسم الخدمة أو الـ CLI
    """
    payload = {
        "sender": sender,
        "receiver": receiver,
        "message": message,
        "cli": cli
    }
    
    headers = {
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(API_URL, data=json.dumps(payload), headers=headers)
        if response.status_code == 200:
            print(f"✅ Success: {response.json()['message']}")
        else:
            print(f"❌ Error: {response.status_code} - {response.json().get('message', 'Unknown error')}")
    except Exception as e:
        print(f"⚠️ Connection Failed: {str(e)}")

# مثال على الاستخدام:
if __name__ == "__main__":
    # افترض أن الرقم '123456789' مخصص ليوزر في اللوحة
    send_sms_to_panel(
        sender="+1999888777", 
        receiver="123456789", 
        message="Your verification code is 5544",
        cli="GOOGLE_AUTH"
    )
