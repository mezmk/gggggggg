# ABYSS PANEL - Enterprise Backend System

هذا النظام هو نسخة مطورة واحترافية (Enterprise Level) لإدارة خدمات الـ SMS، مبني باستخدام Node.js و Express مع قاعدة بيانات SQLite مهيأة بـ 7 جداول وفهارس لتحسين الأداء.

## 🏗️ الهيكل التقني (Architecture)
- **Runtime:** Node.js 18+
- **Framework:** Express.js
- **Database:** SQLite (7 Tables: users, ranges, numbers, traffic, targets, dev_codes, allocation_log)
- **Security:** JWT, Bcrypt (12 rounds), Helmet, CORS, Rate Limiting
- **Optimization:** Compression, Indexed Queries

## 🎯 المميزات الرئيسية
1. **إدارة المستخدمين:** نظام RBAC (Superadmin, Admin, Dev, User).
2. **إدارة النطاقات (Ranges):** دعم رفع وإدارة نطاقات الأرقام.
3. **توزيع الأرقام (Allocation):** نظام توزيع حصري للأرقام للمستخدمين.
4. **تتبع الترافيك (CDR):** تسجيل لحظي للرسائل وحساب الأرباح (Payout).
5. **إحصائيات متقدمة:** لوحة تحكم، رسوم بيانية، وخريطة حرارية (Heatmap).
6. **أكواد المطورين:** نظام دعوات لتسجيل المطورين.

## 🚀 طريقة التشغيل
1. **تثبيت المكتبات:**
   ```bash
   npm install
   ```
2. **بدء التشغيل:**
   ```bash
   node src/server.js
   ```
3. **الدخول للنظام:**
   - الرابط: `http://93.190.143.157:3000`
   - المستخدم الافتراضي: `admin`
   - كلمة المرور: `admin123`

## 📁 هيكل الملفات
- `src/config/`: إعدادات قاعدة البيانات.
- `src/controllers/`: منطق العمل (Business Logic).
- `src/middleware/`: الحماية والتحقق من البيانات.
- `public/`: الواجهة الأمامية (Frontend).
