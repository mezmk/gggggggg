{ pkgs, ... }: {
  channel = "stable-23.11";
  packages = [
    pkgs.nodejs_20
  ];
  idx = {
    extensions = [
      "ms-ceintl.vscode-language-pack-ar"
    ];
    previews = {
      enable = true;
      previews = {
        web = {
          command = ["npm", "run", "start"];
          manager = "web";
          env = {
            PORT = "$PORT";
          };
        };
      };
    };
  };
}
