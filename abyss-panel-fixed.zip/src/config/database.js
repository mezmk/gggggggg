const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');
const bcrypt = require('bcryptjs');

async function initDb() {
    const db = await open({
        filename: path.join(__dirname, '../../database.sqlite'),
        driver: sqlite3.Database
    });

    // 1. Users Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT,
            email TEXT,
            country TEXT,
            role TEXT CHECK(role IN ('superadmin', 'admin', 'dev', 'user')) DEFAULT 'user',
            active INTEGER DEFAULT 1,
            referral_balance REAL DEFAULT 0.0,
            last_login DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // 2. Ranges Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS ranges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            country TEXT,
            prefix TEXT,
            default_payout REAL DEFAULT 0.0,
            default_payterm TEXT,
            total_count INTEGER DEFAULT 0,
            assigned_count INTEGER DEFAULT 0,
            stock_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // 3. Numbers Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS numbers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            number TEXT UNIQUE NOT NULL,
            range_id INTEGER,
            country TEXT,
            assigned_to INTEGER,
            assigned_date DATETIME,
            payout REAL DEFAULT 0.0,
            payterm TEXT,
            active INTEGER DEFAULT 1,
            sms_today INTEGER DEFAULT 0,
            sms_total INTEGER DEFAULT 0,
            last_sms_at DATETIME,
            FOREIGN KEY(range_id) REFERENCES ranges(id),
            FOREIGN KEY(assigned_to) REFERENCES users(id)
        )
    `);

    // 4. Traffic Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS traffic (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            number_id INTEGER,
            number TEXT,
            range_id INTEGER,
            user_id INTEGER,
            cli TEXT,
            sms INTEGER DEFAULT 1,
            payout REAL DEFAULT 0.0,
            currency TEXT DEFAULT 'USD',
            ip TEXT,
            recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(number_id) REFERENCES numbers(id),
            FOREIGN KEY(range_id) REFERENCES ranges(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    `);

    // 5. Targets Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS targets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            type TEXT CHECK(type IN ('daily', 'monthly')),
            value INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    `);

    // 6. Dev Codes Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS dev_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            created_by INTEGER,
            used INTEGER DEFAULT 0,
            used_by INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            used_at DATETIME,
            FOREIGN KEY(created_by) REFERENCES users(id),
            FOREIGN KEY(used_by) REFERENCES users(id)
        )
    `);

    // 7. Allocation Log Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS allocation_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            range_id INTEGER,
            qty INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(range_id) REFERENCES ranges(id)
        )
    `);

    // Indexes for optimization
    await db.exec(`
        CREATE INDEX IF NOT EXISTS idx_numbers_range ON numbers(range_id);
        CREATE INDEX IF NOT EXISTS idx_numbers_assigned ON numbers(assigned_to);
        CREATE INDEX IF NOT EXISTS idx_numbers_number ON numbers(number);
        CREATE INDEX IF NOT EXISTS idx_traffic_number ON traffic(number);
        CREATE INDEX IF NOT EXISTS idx_traffic_user ON traffic(user_id);
        CREATE INDEX IF NOT EXISTS idx_traffic_date ON traffic(recorded_at);
        CREATE INDEX IF NOT EXISTS idx_traffic_range ON traffic(range_id);
    `);

    // Default Admin
    const admin = await db.get('SELECT * FROM users WHERE username = ?', ['admin']);
    if (!admin) {
        const hashedPw = await bcrypt.hash('admin123', 12);
        await db.run('INSERT INTO users (username, password, role, name) VALUES (?, ?, ?, ?)', 
            ['admin', hashedPw, 'superadmin', 'Super Admin']);
    }

    return db;
}

module.exports = initDb;
