const trafficController = (db) => ({
    getTraffic: async (req, res) => {
        const { page = 1, per = 30, q = '' } = req.query;
        const offset = (page - 1) * per;
        try {
            let query = 'SELECT t.*, u.username FROM traffic t JOIN users u ON t.user_id = u.id';
            let params = [];
            if (req.user.role !== 'superadmin' && req.user.role !== 'admin') {
                query += ' WHERE t.user_id = ?';
                params.push(req.user.id);
            }
            if (q) {
                query += (params.length ? ' AND' : ' WHERE') + ' (t.cli LIKE ? OR t.number LIKE ?)';
                params.push(`%${q}%`, `%${q}%`);
            }
            query += ' ORDER BY t.recorded_at DESC LIMIT ? OFFSET ?';
            params.push(parseInt(per), offset);

            const data = await db.all(query, params);
            const total = (await db.get('SELECT COUNT(*) as count FROM traffic')).count;
            res.json({ data, total, page: parseInt(page), per: parseInt(per) });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    getDashboardStats: async (req, res) => {
        try {
            const stats = await db.get(`
                SELECT 
                    SUM(sms) as total_sms, 
                    SUM(payout) as total_payout,
                    (SELECT SUM(referral_balance) FROM users) as referral_balance,
                    (SELECT COUNT(*) FROM users WHERE role = 'user') as active_users,
                    (SELECT COUNT(DISTINCT number) FROM traffic) as assigned_numbers
                FROM traffic
            `);
            res.json(stats || { total_sms: 0, total_payout: 0, active_users: 0, assigned_numbers: 0 });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    getChartData: async (req, res) => {
        const days = parseInt(req.query.days) || 30;
        try {
            const data = await db.all(`
                SELECT date(recorded_at) as label, SUM(sms) as value 
                FROM traffic 
                WHERE recorded_at > date('now', ?)
                GROUP BY date(recorded_at)
                ORDER BY label ASC
            `, [`-${days} days`]);
            res.json({ labels: data.map(d => d.label), values: data.map(d => d.value) });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    getHourlyHeatmap: async (req, res) => {
        try {
            // Mocking heatmap data for 7 days x 24 hours
            const data = Array.from({ length: 7 }, () => Array.from({ length: 24 }, () => Math.floor(Math.random() * 100)));
            res.json({ data });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    getTopCLIs: async (req, res) => {
        try {
            const data = await db.all(`
                SELECT cli, COUNT(*) as count 
                FROM traffic 
                GROUP BY cli 
                ORDER BY count DESC 
                LIMIT 10
            `);
            res.json({ data });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    deleteTraffic: async (req, res) => {
        const { id } = req.params;
        try {
            if (id === 'all') {
                if (req.user.role !== 'superadmin') return res.status(403).json({ message: 'Superadmin only' });
                await db.run('DELETE FROM traffic');
            } else {
                await db.run('DELETE FROM traffic WHERE id = ?', [id]);
            }
            res.json({ message: 'Deleted' });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    }
});

module.exports = trafficController;
