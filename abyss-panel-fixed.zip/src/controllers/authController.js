const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'abyss_super_secret_key_2024';

const authController = (db) => ({
    login: async (req, res) => {
        const { username, password } = req.body;
        try {
            const user = await db.get('SELECT * FROM users WHERE username = ?', [username]);
            if (!user || !(await bcrypt.compare(password, user.password))) {
                return res.status(401).json({ message: 'Invalid username or password' });
            }
            if (!user.active) return res.status(403).json({ message: 'Account is disabled' });

            const token = jwt.sign(
                { id: user.id, username: user.username, role: user.role, name: user.name },
                JWT_SECRET,
                { expiresIn: '24h' }
            );

            await db.run('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);

            res.json({ token, user: { id: user.id, username: user.username, role: user.role, name: user.name } });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    register: async (req, res) => {
        const { username, password, name, dev_code } = req.body;
        try {
            let role = 'user';
            if (dev_code) {
                const code = await db.get('SELECT * FROM dev_codes WHERE code = ? AND used = 0', [dev_code]);
                if (!code) return res.status(400).json({ message: 'Invalid or used dev code' });
                role = 'dev';
            }

            const hashedPw = await bcrypt.hash(password, 12);
            const result = await db.run(
                'INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)',
                [username, hashedPw, name, role]
            );

            if (dev_code) {
                await db.run('UPDATE dev_codes SET used = 1, used_by = ?, used_at = CURRENT_TIMESTAMP WHERE code = ?', [result.lastID, dev_code]);
            }

            res.status(201).json({ message: 'User registered successfully' });
        } catch (e) {
            if (e.message.includes('UNIQUE')) return res.status(400).json({ message: 'Username already exists' });
            res.status(500).json({ message: e.message });
        }
    },

    changePassword: async (req, res) => {
        const { currentPassword, newPassword } = req.body;
        try {
            const user = await db.get('SELECT * FROM users WHERE id = ?', [req.user.id]);
            if (!(await bcrypt.compare(currentPassword, user.password))) {
                return res.status(400).json({ message: 'Incorrect current password' });
            }

            const hashedPw = await bcrypt.hash(newPassword, 12);
            await db.run('UPDATE users SET password = ? WHERE id = ?', [hashedPw, req.user.id]);
            res.json({ message: 'Password updated successfully' });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    }
});

module.exports = authController;
