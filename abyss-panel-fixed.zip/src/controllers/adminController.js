const adminController = (db) => ({
    getUsers: async (req, res) => {
        try {
            const users = await db.all('SELECT id, username, name, role, active, last_login, created_at FROM users');
            res.json({ data: users });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    getUserPerformance: async (req, res) => {
        try {
            const data = await db.all(`
                SELECT u.id, u.username, u.name, 
                       COUNT(DISTINCT t.number) as numbers_count,
                       SUM(t.sms) as sms_count,
                       SUM(t.payout) as total_payout
                FROM users u
                LEFT JOIN traffic t ON u.id = t.user_id
                WHERE u.role = 'user'
                GROUP BY u.id
                ORDER BY sms_count DESC
            `);
            res.json({ data });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    getSystemInfo: async (req, res) => {
        try {
            res.json({
                node_version: process.version,
                uptime: Math.floor(process.uptime()) + 's',
                memory_used: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2) + ' MB',
                db_version: 'SQLite 3',
                total_users: (await db.get('SELECT COUNT(*) as c FROM users')).c,
                total_numbers: (await db.get('SELECT COUNT(DISTINCT number) as c FROM traffic')).c
            });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    getDevCodes: async (req, res) => {
        try {
            const codes = await db.all(`
                SELECT dc.*, u1.username as creator, u2.username as used_by_user 
                FROM dev_codes dc 
                LEFT JOIN users u1 ON dc.created_by = u1.id 
                LEFT JOIN users u2 ON dc.used_by = u2.id 
                ORDER BY dc.created_at DESC
            `);
            res.json(codes);
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    generateDevCode: async (req, res) => {
        try {
            const code = Math.random().toString(36).substring(2, 10).toUpperCase();
            await db.run('INSERT INTO dev_codes (code, created_by) VALUES (?, ?)', [code, req.user.id]);
            res.json({ code });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    },

    deleteDevCode: async (req, res) => {
        const { id } = req.params;
        try {
            await db.run('DELETE FROM dev_codes WHERE id = ?', [id]);
            res.json({ message: 'Deleted' });
        } catch (e) {
            res.status(500).json({ message: e.message });
        }
    }
});

module.exports = adminController;
