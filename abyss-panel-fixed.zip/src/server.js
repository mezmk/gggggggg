const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const path = require('path');
const os = require('os');
const initDb = require('./config/database');
const { authenticate, authorize } = require('./middleware/auth');

const app = express();
// في IDX يفضل استخدام المنفذ 3000 أو 8080، المنفذ 80 قد يتطلب صلاحيات root
const PORT = process.env.PORT || 3000;

// دالة للحصول على IP السيرفر (للعرض فقط)
function getServerIP() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                return iface.address;
            }
        }
    }
    return 'localhost';
}

const SERVER_IP = getServerIP();

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(compression());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Database Initialization
initDb().then(db => {
    // Controllers
    const authCtrl = require('./controllers/authController')(db);
    const trafficCtrl = require('./controllers/trafficController')(db);
    const adminCtrl = require('./controllers/adminController')(db);

    // --- Auth Routes ---
    app.post('/api/auth/login', authCtrl.login);
    app.post('/api/auth/register', authCtrl.register);
    app.put('/api/auth/password', authenticate, authCtrl.changePassword);

    // --- Traffic Routes ---
    app.get('/api/traffic', authenticate, trafficCtrl.getTraffic);
    app.get('/api/traffic/stats/dashboard', authenticate, trafficCtrl.getDashboardStats);
    app.get('/api/traffic/stats/chart', authenticate, trafficCtrl.getChartData);
    app.get('/api/traffic/stats/hourly', authenticate, trafficCtrl.getHourlyHeatmap);
    app.get('/api/traffic/stats/cli', authenticate, trafficCtrl.getTopCLIs);
    app.delete('/api/traffic/:id', authenticate, trafficCtrl.deleteTraffic);

    // --- Admin Routes ---
    app.get('/api/users', authenticate, authorize(['superadmin', 'admin']), adminCtrl.getUsers);
    app.get('/api/admin/user-performance', authenticate, authorize(['superadmin', 'admin']), adminCtrl.getUserPerformance);
    app.get('/api/admin/system-info', authenticate, authorize(['superadmin', 'admin']), adminCtrl.getSystemInfo);
    app.get('/api/admin/dev-codes', authenticate, authorize(['superadmin', 'admin']), adminCtrl.getDevCodes);
    app.post('/api/admin/dev-codes', authenticate, authorize(['superadmin', 'admin']), adminCtrl.generateDevCode);
    app.delete('/api/admin/dev-codes/:id', authenticate, authorize(['superadmin', 'admin']), adminCtrl.deleteDevCode);

    // --- Targets Routes ---
    app.get('/api/targets', authenticate, async (req, res) => {
        const data = await db.all('SELECT * FROM targets');
        res.json({ data });
    });
    app.put('/api/targets/:userId/:type', authenticate, authorize(['superadmin', 'admin']), async (req, res) => {
        const { userId, type } = req.params;
        const { value } = req.body;
        const existing = await db.get('SELECT id FROM targets WHERE user_id = ? AND type = ?', [userId, type]);
        if (existing) {
            await db.run('UPDATE targets SET value = ? WHERE id = ?', [value, existing.id]);
        } else {
            await db.run('INSERT INTO targets (user_id, type, value) VALUES (?, ?, ?)', [userId, type, value]);
        }
        res.json({ message: 'Saved' });
    });

    // --- External APIs ---
    
    // 1. API to get all users and their assigned numbers
    app.get('/api/external/users-numbers', authenticate, authorize(['superadmin', 'admin']), async (req, res) => {
        try {
            const data = await db.all(`
                SELECT u.id as user_id, u.username, u.name, n.number, n.payout
                FROM users u
                JOIN numbers n ON u.id = n.assigned_to
                WHERE u.active = 1
            `);
            res.json({ success: true, data });
        } catch (e) {
            res.status(500).json({ success: false, message: e.message });
        }
    });

    // 2. API to receive external SMS and update traffic + referral points
    app.post('/api/external/receive-sms', async (req, res) => {
        const { sender, receiver, message, cli } = req.body;
        try {
            const numberInfo = await db.get('SELECT * FROM numbers WHERE number = ? AND active = 1', [receiver]);
            if (!numberInfo || !numberInfo.assigned_to) {
                return res.status(404).json({ success: false, message: 'Number not found or not assigned' });
            }
            const userId = numberInfo.assigned_to;
            const payout = numberInfo.payout || 0.01;
            await db.run(`
                INSERT INTO traffic (number_id, number, user_id, cli, sms, payout, ip)
                VALUES (?, ?, ?, ?, 1, ?, ?)
            `, [numberInfo.id, receiver, userId, cli || sender, payout, req.ip]);
            await db.run('UPDATE users SET referral_balance = referral_balance + 0.005 WHERE id = ?', [userId]);
            await db.run(`
                UPDATE numbers 
                SET sms_today = sms_today + 1, 
                    sms_total = sms_total + 1, 
                    last_sms_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            `, [numberInfo.id]);
            res.json({ success: true, message: 'SMS processed and points added' });
        } catch (e) {
            res.status(500).json({ success: false, message: e.message });
        }
    });

    // Health Check
    app.get('/health', (req, res) => res.json({ status: 'OK' }));

    // Start Server
    // الاستماع على 0.0.0.0 ضروري في IDX ليتمكن الـ Port Forwarding من العمل
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`\n🚀 ABYSS PANEL is running!`);
        console.log(`📡 Local IP: http://${SERVER_IP}:${PORT}`);
        console.log(`🌍 Public Access: Check the 'IDX' tab or the 'Port Forwarding' notification in your browser.\n`);
    });
}).catch(err => {
    console.error('Failed to initialize database:', err);
});
